<?php
session_start();

// Initialize the game
if (!isset($_SESSION['word'])) {
    $words = ['nice', 'cruel', 'introvert', 'extrovert', 'misunderstood', 'mental', 'psycho', 'bully', 'supportive', 'offensive'];
    $_SESSION['word'] = $words[array_rand($words)]; // Randomly select a word
    $_SESSION['guessed'] = [];
    $_SESSION['wrong_guesses'] = 0;
    $_SESSION['max_attempts'] = 10; // Number of allowed wrong guesses
}

$word = $_SESSION['word'];
$guessed = $_SESSION['guessed'];
$wrong_guesses = $_SESSION['wrong_guesses'];
$max_attempts = $_SESSION['max_attempts'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['letter'])) {
    $letter = strtolower($_POST['letter']); // Convert to lowercase for uniformity

    // Check if the letter is valid (single alphabet character)
    if (preg_match('/^[a-z]$/', $letter)) {
        // Check if the letter was guessed before
        if (!in_array($letter, $guessed)) {
            $guessed[] = $letter;
            $_SESSION['guessed'] = $guessed;

            if (!str_contains($word, $letter)) {
                $wrong_guesses++;
                $_SESSION['wrong_guesses'] = $wrong_guesses;
            }
        }
    }
}

// Generate the display word with underscores
$display_word = '';
foreach (str_split($word) as $char) {
    $display_word .= in_array($char, $guessed) ? $char : '_';
}

// Check for game over conditions
$game_over = false;
if ($wrong_guesses >= $max_attempts) {
    $game_over = true;
    $message = "Game Over! The word was <strong>$word</strong>";
    header("Location: magicdoor.html");
    exit;
} elseif (!str_contains($display_word, '_')) {
    $game_over = true;
    $message = "Congratulations! You've guessed the word <strong>$word</strong>";
    header("Location: magicdoor.html");
    exit;
}

// Calculate the current image based on wrong guesses
$image_path = "Assets/" . min($wrong_guesses, 10) . ".jpg";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hangman</title>
    <link rel="stylesheet" href="style.css">
    </style>
    <script>
        function validateInput() {
            const letter = document.getElementById('letter').value;
            const error = document.getElementById('error');

            if (!/^[a-zA-Z]$/.test(letter)) {
                error.textContent = 'Please enter a valid single letter.';
                return false;
            }
            error.textContent = '';
            return true;
        }
    </script>
</head>
<body>
    <div class="container">
        <p>You wake up in a room with a rope. You must correctly guess the word before Benji changes him mind</p>
        <div class="image-container">
            <img src="<?= $image_path ?>" alt="Hangman Progress">
        </div>
        <div class="game-info">
            <p>Word to Guess: <span><?= $display_word ?></span></p>
            <p>Guessed Letters: <span><?= implode(', ', $guessed) ?></span></p>
            <p>Wrong Guesses: <span><?= $wrong_guesses ?> / <?= $max_attempts ?></span></p>
        </div>

        <?php if (!$game_over): ?>
            <form method="POST" onsubmit="return validateInput();">
                <label for="letter">Guess a letter:</label>
                <input type="text" name="letter" id="letter" maxlength="1" required>
                <button type="submit">Guess</button>
                <p id="error" class="error"></p>
            </form>
        <?php else: ?>
            <p><?= $message ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
