<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Story 3: Gangsta Town</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
    <h1>Gangsta Town</h1>
    <a href="magicdoor.html"><button class="back">Back to Main</button></a>
    <br><br>

    <div id="story-container">
        <?php
        echo "<h2>Story 3: Gangsta Town</h2>";
        ?>
    </div>

    <script>
        let opponentStunned = false; // Tracks whether the gangsta is stunned

        function chooseGangstaAction(choice) {
            if (choice === 'fight') {
                displayFightPath();
            } else if (choice === 'nice') {
                setTimeout(() => {
                    alert("As you lower your guard, a hard blow knocks you out cold...");
                    window.location.href = "blackout.html"; // Replace with your page URL
                }, 2000);
            }
        }

        function displayFightPath() {
            const storyContainer = document.getElementById("story-container");

            storyContainer.innerHTML = `
                <h2>You chose to fight the gangsta...</h2>
                <p>Shadow Benji narrows his eyes as he pulls out a knife, his lips curling into a sinister grin.</p>
                <p>“Let’s see what you’re made of,” he growls, advancing toward you.</p>
                <h3>Your next move?</h3>
                <div class="choices">
                    <button onclick="stunOpponent()">Stun the gangsta</button>
                    <button onclick="blockAttack()">Block the attack</button>
                    <button onclick="distractOpponent()">Distract the gangsta</button>
                    <button onclick="runAway()">Run Away</button>
                </div>
            `;
        }

        function stunOpponent() {
            opponentStunned = true; // The opponent is stunned
            const storyContainer = document.getElementById("story-container");

            storyContainer.innerHTML = `
                <h2>You managed to stun Shadow Benji!</h2>
                <p>Grabbing a trash can lid from the ground, you smash it into Benji’s head. He staggers, groaning in pain, giving you a chance to act.</p>
                <h3>Your next move?</h3>
                <div class="choices">
                    <button onclick="runAway()">Run Away</button>
                    <button onclick="finishOpponent()">Try to finish him off</button>
                </div>
            `;
        }

        function blockAttack() {
            const storyContainer = document.getElementById("story-container");

            storyContainer.innerHTML = `
                <h2>You chose to block the gangsta’s attack...</h2>
                <p>Using your quick reflexes, you block Benji’s knife strike with your arm, avoiding a fatal blow but suffering a deep cut.</p>
                <p>You’re bleeding heavily, but Benji appears frustrated, giving you an opening to retaliate.</p>
                <h3>Your next move?</h3>
                <div class="choices">
                    <button onclick="stunOpponent()">Stun the gangsta</button>
                    <button onclick="runAway()">Run Away</button>
                </div>
            `;
        }

        function distractOpponent() {
            const storyContainer = document.getElementById("story-container");

            storyContainer.innerHTML = `
                <h2>You chose to distract the gangsta...</h2>
                <p>Pointing behind him, you shout, “What’s that?” Benji instinctively turns his head, giving you a brief window of opportunity.</p>
                <h3>Your next move?</h3>
                <div class="choices">
                    <button onclick="stunOpponent()">Stun the gangsta</button>
                    <button onclick="runAway()">Run Away</button>
                </div>
            `;
        }

        function runAway() {
            const storyContainer = document.getElementById("story-container");

            if (!opponentStunned) {
                storyContainer.innerHTML = `
                    <h2>You tried to run away...</h2>
                    <p>Shadow Benji reacts with lightning speed, pulling a gun from his jacket. Before you can escape, a shot rings out.</p>
                    <p>The bullet finds its mark. As your vision fades, Benji’s mocking laughter echoes in your ears. You died.</p>
                `;
            } else {
                storyContainer.innerHTML = `
                    <h2>You ran away successfully...</h2>
                    <p>While Benji is still dazed, you sprint down the dark, narrow alleyways of Gangsta Town. The flickering neon signs blur as you run for your life.</p>
                    <p>You eventually reach the city’s outskirts, safe but shaken. This night will haunt you forever...</p>
                `;
            }
        }

        function finishOpponent() {
            const storyContainer = document.getElementById("story-container");

            storyContainer.innerHTML = `
                <h2>You chose to finish off Shadow Benji...</h2>
                <p>Using all your strength, you deliver a final blow, rendering Benji unconscious. Breathing heavily, you realize you’ve done the unthinkable—defeated one of Gangsta Town’s most feared criminals.</p>
                <p>Though victorious, you know staying here is dangerous. You quickly leave the scene, blending into the chaotic streets of the city.</p>
                <p>You’ve survived... for now.</p>
            `;
        }

        function displayInitialGangstaStory() {
            const storyContainer = document.getElementById("story-container");

            setTimeout(function () {
                storyContainer.innerHTML += '<img src="Assets/gangsta.jpeg" alt="Gangsta Town" style="width: 100%; max-width: 600px;">';
            }, 3000);

            setTimeout(function () {
                storyContainer.innerHTML += `
                    <p>It’s been five years since you last set foot in Gangsta Town, a crumbling urban wasteland controlled by ruthless gangs.</p>`;
            }, 7000);

            setTimeout(function () {
                storyContainer.innerHTML += `
                    <p>As you navigate the dimly lit alleys, you hear the crunch of footsteps. A towering figure steps into your path—Shadow Benji, a name that strikes fear across the city.</p>
                    <p>“Another visitor in my territory,” he sneers. “Let’s see if you’re tough enough to survive.”</p>`;
            }, 11000);

            setTimeout(function () {
                storyContainer.innerHTML += `
                    <h3>What will you do?</h3>
                    <div class="choices">
                        <button onclick="chooseGangstaAction('fight')">Fight the gangsta</button>
                        <button onclick="chooseGangstaAction('nice')">Be nice</button>
                    </div>`;
            }, 15000);
        }

        window.onload = function() {
            displayInitialGangstaStory();
        };
    </script>
</body>
</html>
