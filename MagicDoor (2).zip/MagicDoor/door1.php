<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Story 1: Lost in the forest</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
    <h1>Magic Door Adventure!</h1>
    <a href="magicdoor.html"><button class="back">Back to Main</button></a>
    <br>
    <br>

    <div id="story-container">
        <?php
        if (!isset($_GET['instinct'])) {
            echo 'Story 1: In the forest';
        }
        ?>
    </div>

    <script>
        // Function to handle subdoor selection
        function chooseDoor(instinctValue) {
            window.location.href = `?instinct=${instinctValue}`;
        }

        function displayNewStory(instinct) {
            const storyContainer = document.getElementById("story-container");

            // Outcome branches based on chosen door and subdoor
            if (instinct === 0) {
                // Door 1: Survival Tips
                storyContainer.innerHTML = `
                    <h2>You chose Survival Tips.</h2>
                    <p>You use your wilderness knowledge to navigate.</p>
                    <p>Eventually, you find signs that lead you closer to survival options.</p>
                    <div class="subdoors">
                        <div class="subdoor" onclick="chooseDoor(10)">
                           <button> <p>Follow Animal Tracks</p> </button>
                        </div>
                        <div class="subdoor" onclick="chooseDoor(11)">
                            <button><p>Follow the Flow of Water</p></button>
                        </div>
                    </div>
                `;
            } else if (instinct === 1) {
                // Door 2: Natural Instinct
                storyContainer.innerHTML = `
                    <h2>You chose Natural Instinct.</h2>
                    <p>You trust your instincts and head deeper into the forest.</p>
                    <p>After hours of walking, you come to a fork in the path.</p>
                    <div class="subdoors">
                        <div class="subdoor" onclick="chooseDoor(20)">
                            <button><p>Take the Left Path</p></button>
                        </div>
                        <div class="subdoor" onclick="chooseDoor(21)">
                            <button><p>Take the Right Path</p></button>
                        </div>
                    </div>
                `;
            } else if (instinct === 10) {
                // Follow Animal Tracks: Failure
                storyContainer.innerHTML = `
                    <h2>You chose to follow animal tracks...</h2>
                    <p>As you trek deeper into the forest, you realize the tracks belong to a predator.</p>
                    <p>Suddenly, a tiger leaps out of the bushes and mauls you and your friends. The journey ends here.</p>
                `;
            } else if (instinct === 11 || instinct === 20) {
                // Follow the River (Success) or Left Path leading to the River
                storyContainer.innerHTML = `
                    <h2>You chose to follow the flow of water...</h2>
                    <p>The river leads you to a small village. The villagers help you return to civilization.</p>
                    <p>Your instincts and survival knowledge saved the day!</p>
                `;
            } else if (instinct === 21) {
                // Right Path: Failure
                storyContainer.innerHTML = `
                    <h2>You chose the right path...</h2>
                    <p>The path leads to a steep cliff. As you approach, strong winds make it hard to stand.</p>
                    <p>A gust of wind knocks you and your friend off the cliff. Your story ends tragically here.</p>
                `;
            }
        }

        // Check the query parameter for the instinct value
        window.onload = function() {
            const urlParams = new URLSearchParams(window.location.search);
            const instinct = parseInt(urlParams.get('instinct'), 10);

            if (!isNaN(instinct)) {
                displayNewStory(instinct);
            } else {
                // Display the initial story with timed content
                displayInitialStory();
            }
        };

        function displayInitialStory() {
            const storyContainer = document.getElementById("story-container");

            setTimeout(function () {
                storyContainer.innerHTML += '<br><img src="Assets/forest.jpg" alt="Forest">';
            }, 3000);

            setTimeout(function () {
                storyContainer.innerHTML += "<p>You are hiking with your friends in the forest until...</p>";
            }, 7000);

            setTimeout(function () {
                storyContainer.innerHTML += "<p>You lost navigation while hiking</p>";
            }, 11000);

            setTimeout(function () {
                storyContainer.innerHTML += "<p>A friend suggested we use our wilderness knowledge by using the trees, plants, etc.</p>";
            }, 15400);

            setTimeout(function () {
                storyContainer.innerHTML += "<p>Another friend decided that we must trust our natural instinct</p>";
            }, 17400);

            setTimeout(function () {
                storyContainer.innerHTML += "<h2>Who do you trust?</h2>";
            }, 20400);

            setTimeout(function () {
                storyContainer.innerHTML += `
                    <div class="doors">
                        <div class="door" onclick="chooseDoor(0)">
                            <img src="Assets/door.png" alt="Magic Door">
                            <p>Survival Tips</p>
                        </div>
                        <div class="door" onclick="chooseDoor(1)">
                            <img src="Assets/door.png" alt="Magic Door">
                            <p>Natural Instinct</p>
                        </div>
                    </div>
                `;
            }, 25000);
        }
    </script>

    <?php
    if (isset($_GET['instinct'])) {
        $instinct = (int)$_GET['instinct'];
        echo "<script>displayNewStory($instinct);</script>";
    }
    ?>
</body>
</html>
