<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Story 2: Deep Sea Adventure</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
    <h1>Deep Sea Adventure</h1>
    <a href="magicdoor.html"><button class="back">Back to Main</button></a>
    <br>
    <br>

    <div id="story-container">
        <?php
        echo "<h2>Story 2: Deep Sea Adventure</h2>";
        ?>
    </div>

    <script>
        function chooseAction(choice) {
            window.location.href = `?story2=${choice}`;
        }

        function displaySubmarineStory(stage) {
            const storyContainer = document.getElementById("story-container");

            if (stage === "descend") {
                storyContainer.innerHTML = `
                    <h2>You chose to explore deeper...</h2>
                    <p>As the submarine descends further into the ocean, the increasing pressure causes the submarine to begin leaking water.</p>
                    <h3>What will you do?</h3>
                    <div class="choices">
                        <button onclick="chooseAction('fix')">Try to fix the leak at this spot</button>
                        <button onclick="chooseAction('surface')">Ascend immediately</button>
                    </div>
                `;
            } else if (stage === "fix") {
                storyContainer.innerHTML = `
                    <h2>You chose to fix the leak on the spot...</h2>
                    <p>Unfortunately, the intense pressure proves too much, and the submarine floods entirely. The crew and you tragically drown.</p>
                    <p>Your journey ends here.</p>
                `;
            } else if (stage === "surface") {
                storyContainer.innerHTML = `
                    <h2>You chose to ascend immediately...</h2>
                    <p>The submarine safely surfaces. Despite the scary encounter, you and the crew manage to reach the jetty safely. You survived!</p>
                `;
            } else if (stage === "ascend") {
                storyContainer.innerHTML = `
                    <h2>You chose to stay at the same altitude...</h2>
                    <p>As you continue your exploration, you encounter a large shark swimming nearby.</p>
                    <h3>How will you respond?</h3>
                    <div class="choices">
                        <button onclick="chooseAction('experiment')">Run an experiment (risky)</button>
                        <button onclick="chooseAction('ignore')">Completely ignore the shark</button>
                        <button onclick="chooseAction('runaway')">Run away</button>
                    </div>
                `;
            } else if (stage === "experiment") {
                storyContainer.innerHTML = `
                    <h2>You chose to run an experiment...</h2>
                    <p>The experiment distracts the shark momentarily. After a tense few minutes, the shark loses interest and swims away.</p>
                    <p>You continue your journey and eventually return safely. A risky but successful venture!</p>
                `;
            } else if (stage === "ignore") {
                storyContainer.innerHTML = `
                    <h2>You chose to completely ignore the shark...</h2>
                    <p>Luckily, the shark pays no attention to your submarine. You complete the journey and return safely to the jetty.</p>
                `;
            } else if (stage === "runaway") {
                storyContainer.innerHTML = `
                    <h2>You chose to try and run away from the shark...</h2>
                    <p>The shark aggressively chases the submarine. Its speed and strength prove too much as it slams into the sub, breaking it open.</p>
                    <p>The shark devours everyone aboard. A tragic end to the journey.</p>
                `;
            }
        }

        function displayInitialStory() {
            const storyContainer = document.getElementById("story-container");

            setTimeout(function () {
                storyContainer.innerHTML += '<br><img src="Assets/sub.jpeg" alt="Submarine" style="width: 100%; max-width: 600px;">';
            }, 3000);

            setTimeout(function () {
                storyContainer.innerHTML += '<p>After one hour of exploring in a submarine with a navy captain, you are presented with a choice:</p>';
            }, 7000);

            setTimeout(function () {
                storyContainer.innerHTML += '<p>Do you wish to explore deeper or continue exploring at the same altitude?</p>';
            }, 11000);

            setTimeout(function () {
                storyContainer.innerHTML += '<div class="choices"><button onclick="chooseAction(\'descend\')">Explore Deeper</button><button onclick="chooseAction(\'ascend\')">Stay at Same Altitude</button></div>';
            }, 15000);
        }

        window.onload = function() {
            const urlParams = new URLSearchParams(window.location.search);
            const story2Stage = urlParams.get('story2');

            if (story2Stage) {
                displaySubmarineStory(story2Stage);
            } else {
                displayInitialStory();
            }
        };
    </script>
</body>
</html>
